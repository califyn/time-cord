# Quantify & take control of time spent on Discord

Current features:
- None

(In development) Functions that can:
- Track time spent on Discord
- Track time spent on specific servers & channels
- Close Discord after too much time is spent
...without violating Discord ToS!

Areas for improvement:
- Support for non-Mac OS devices

Dependencies:
- None
